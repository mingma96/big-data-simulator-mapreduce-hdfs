package observer;

import application.Application;

public interface AppObserver {
	public void map(Application app);
}
