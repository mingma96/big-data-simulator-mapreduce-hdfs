package observer;

import application.Application;

public interface MapObserver {
	public void compute(Application app);
}
