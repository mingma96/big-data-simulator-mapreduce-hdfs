package resource;

public class CPU {
	private static float frequency;

	public static float getfrequency() {
		return frequency;
	}

	public static void setfrequency(float frequency) {
		CPU.frequency = frequency;
	}
	
	
}
