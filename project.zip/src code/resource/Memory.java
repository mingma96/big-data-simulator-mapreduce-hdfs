package resource;

public class Memory {
	private static int size;

	public static int getSize() {
		return size;
	}

	public static void setSize(int size) {
		Memory.size = size;
	}
	
	
}
