package resource;

public class NetworkBW {
	private static int speed;

	public static int getSpeed() {
		return speed;
	}

	public static void setSpeed(int speed) {
		NetworkBW.speed = speed;
	}
	
	
}
