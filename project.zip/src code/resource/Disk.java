package resource;

public class Disk {
	private static int space;

	
	//Getters and setters
	public static int getSpace() {
		return space;
	}

	public static void setSpace(int space) {
		Disk.space = space;
	}
	
	
}
