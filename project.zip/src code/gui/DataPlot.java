package gui;

public class DataPlot {
	private double size;
	private double time;
	private double nodeNum;
	
	public double getNodeNum() {
		return nodeNum;
	}
	public void setNodeNum(double nodeNum) {
		this.nodeNum = nodeNum;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public double getTime() {
		return time;
	}
	public void setTime(double time) {
		this.time = time;
	}
	
	

}
